<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.cards', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="container-fluid mt--5">
    <div class="col-xl-8 order-xl-1">
    <div class="card bg-secondary shadow">
        <div class="card-header bg-white border-0">
            <div class="row align-items-center">
                <h3 class="col-12 mb-0"><?php echo e(__('Add New Post')); ?></h3>
            </div>
        </div>
        <div class="card-body">
            <form action="/p/create" method="POST" enctype="multipart/form-data" autocomplete="off">
                <?php echo csrf_field(); ?>
            

                <div class="pl-lg-4">
                    <div class="form-group<?php echo e($errors->has('caption') ? ' has-danger' : ''); ?>">
                        <label class="form-control-label" for="input-name"><?php echo e(__('Post Caption')); ?></label>
                        <input type="text" name="caption" id="input-caption" class="form-control form-control-alternative<?php echo e($errors->has('caption') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Caption')); ?>" value="<?php echo e(old('caption')); ?>" required autofocus>

                        <?php if($errors->has('caption')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('caption')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>


                    <div class="form-group<?php echo e($errors->has('image') ? ' has-danger' : ''); ?>">
                        <label class="form-control-label" for="input-image"><?php echo e(__('Post Image')); ?></label>
                        <div style="position:relative;">
                            <a class='btn btn-primary' href='javascript:;'>
                                Choose File...
                                <input type="file" style='position:absolute;z-index:2;top:0;left:0;filter: alpha(opacity=0);-ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";opacity:0;background-color:transparent;color:transparent;' name="image" onchange='$("#upload-file-info").html($(this).val());' value="<?php echo e(old('image')); ?>" required>
                            </a>
                            &nbsp;
                            <span class='label label-info' id="upload-file-info"></span>
                        </div>
                    </div>
                    <?php if($errors->has('image')): ?>
                        <h5 role="alert" style="color:#fb6340">
                            <strong><?php echo e($errors->first('image')); ?></strong> 
                        </h5>
                    <?php endif; ?>

                    <div class="text-center">
                        <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Add New Post')); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Ampps\www\instagram\resources\views/posts/create.blade.php ENDPATH**/ ?>