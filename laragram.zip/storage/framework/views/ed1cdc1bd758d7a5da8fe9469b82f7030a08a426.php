<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.cards', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container mt--7">
    <div class="row">
        <div class="col-xl-8">
            <img src="/storage/<?php echo e($post->image); ?>" alt="img" class="w-100 mb-3">
        </div>

        <div class="col-lg-4">
            <div class="d-flex align-items-center" >
                <div class="pr-3">
                    <img src="/storage/<?php echo e($post->user->profile->image); ?>" alt="img" class="rounded-circle w-100" style="max-width: 40px" >
                </div>
                <div class="font-weight-bold d-flex">
                    <a href="/profile/<?php echo e($post->user->username); ?>">
                    <span class="text-dark mr-3"> <?php echo e($post->user->username); ?> </span> 
                    </a>
                    <follow-button user-username="<?php echo e(Auth::user()->username); ?>" follows="<?php echo e($follows); ?>"></follow-button>   
                </div>
            </div>    
            
            <hr> 
            
            <div class="font-weight-bold d-flex">
                <div class="pr-2"><a href="/profile/<?php echo e($post->user->username); ?>">
                    <span class="text-dark"> <?php echo e($post->user->username); ?> </span> </a>
                </div>

                <p><?php echo e($post->caption); ?></p>
            </div>      
            
        </div>    
    </div>
    <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Ampps\www\instagram\resources\views/posts/show.blade.php ENDPATH**/ ?>