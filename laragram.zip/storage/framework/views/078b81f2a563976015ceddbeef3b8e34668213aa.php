<div class="header py-5 py-lg-5">
    <div class="container">
        <div class="header-body text-center mb-7">
            <div class="row justify-content-center">
                <div class="col-lg-5 col-md-6">
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Ampps\www\instagram\resources\views/layouts/headers/guest.blade.php ENDPATH**/ ?>