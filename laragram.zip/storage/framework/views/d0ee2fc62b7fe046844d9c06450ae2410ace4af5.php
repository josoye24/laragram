<nav class="navbar navbar-top navbar-horizontal navbar-expand-md navbar-dark">

</nav><?php /**PATH C:\Ampps\www\instagram\resources\views/layouts/navbars/navs/guest.blade.php ENDPATH**/ ?>