<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.cards', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="container-fluid mt--7">
    <div class="row">
        <div class="col-xl-8 mb-5 mb-xl-0">
            <h2 class="mb-3">Featured Stories</h2>
            <div class="bg-transparent">
                <div class="row align-items-center">

                    <?php $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-3 col-6 mb-4">
                            <a href = "/p/<?php echo e($story->slug); ?>">
                            <img src="/storage/<?php echo e($story->image); ?>" alt="img" class="w-100" style="border-radius: 5%">
                            </a>
                            
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>

            <hr>


            <h2 class="mb-4">Latest Feed</h2>

            <div class="container">
                <div class="row">
                    <div class="row justify-content-center">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xl-9 col-sm-0 pb-5">
                                <a href = "/p/<?php echo e($post->slug); ?>">
                                <img src="/storage/<?php echo e($post->image); ?>" alt="img" class="w-100">
                                </a>
                                <div class="font-weight-bold"> 
                                    <a href="/profile/<?php echo e($post->username); ?>">
                                        <span class="text-dark"> <?php echo e($post->username); ?> </span>
                                    </a> 
                                </div>  <?php echo e($post->caption); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php if(empty($post)): ?>
                            <div class="col">No post to show, follow users to get post</div>
                        <?php endif; ?>
            
                        <div class="justify-content-center">
                            <div class="col">
                                <?php echo e($posts->links()); ?>

                            </div>
                        </div>
                    </div>  
            
                </div>
            </div>
            <hr>


        </div>

        <!--New Followers-->
        
        <div class="col-xl-4">
            <h2 class="mb-3 text-muted">New Followers</h2>
            <?php $__currentLoopData = $newFollowers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $followers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white shadow-sm mb-2 p-2 pl-4" style="border-radius:15px">

                <div class="row align-items-center">
                    <div class="pl-3 pr-1" >
                        <img src="/storage/<?php echo e($followers->profile->image); ?>" alt="img" class="rounded-circle w-100" id="ProfileCircleSmall" style="max-width: 45px" >
                    </div>
                    <div class="div col-9">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <a href="/profile/<?php echo e($followers->username); ?>"> <span class="text-dark"> <?php echo e($followers->name); ?> </span>
                                <br><small class="text-muted"> @ <?php echo e($followers->username); ?> </small> </a>
                            </div>
                             <follow-button user-username="<?php echo e($followers->username); ?>" follows="<?php echo e($follows); ?>"></follow-button>
                        </div>
                    </div>    
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
     <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Ampps\www\instagram\resources\views/posts/index.blade.php ENDPATH**/ ?>