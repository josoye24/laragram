<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.cards', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    

<div class="container-fluid mt--7">
    <div class="row">
        <div class="col-xl-8 mb-5 mb-xl-0">

            <?php if(session('post_status')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('post_status')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>

            <h2 class="mb-3">Latest Feed</h2>
            <div class="bg-transparent">
                <div class="row align-items-center">

                    <?php $__currentLoopData = $profilePost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-4 col-sm-6 mb-4">
                            <a href = "/p/<?php echo e($post->slug); ?>">
                            <img src="/storage/<?php echo e($post->image); ?>" alt="img" class="w-100" style="border-radius: 5%">
                            </a>
                            
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if(empty($post)): ?>
                            <div class="col">No post to show, post someting to show here</div>
                    <?php endif; ?>

                </div>
            </div>
            
            <div class="justify-content-center">
                <div class="col">
                    <?php echo e($profilePost->links()); ?>

                </div>
            </div>

            <hr>


        </div>
        
        <!--Righ Bar-->
        <div class="col-xl-4">
            <div class="card-header bg-transparent">
                <div class="col mb-2">
                    <img src="/storage/<?php echo e($users->profile->image); ?>" alt="profile pix" class="w-100" style="border-radius: 5%">
                </div>
                
                <div class="col text-center">
                    <h2 class="mb-1"><?php echo e($users->name); ?></h2>
                    <div class="justify-content-center align-items-center d-flex ">
                        <h5 class="text-muted mr-3"> @ <?php echo e($users->username); ?> </h5>

                        <!-- Follow Button using VueJS-->
                        <?php if(Gate::allows('update', $users->profile)): ?> 
                            <a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-sm btn-primary mb-2">Edit Profile</a>    
                        <?php else: ?>    
                            <follow-button user-username="<?php echo e($user->username); ?>" follows="<?php echo e($follows); ?>"></follow-button>   
                        <?php endif; ?>

                            
                        
                    </div>    
                    <div class="d-inline-flex mb-4">
                        <h4> <?php echo e($usersPostCount); ?> <h4 class="font-weight-normal text-muted pl-1 mr-4 "> Posts </h4></h4>
                        <h4> <?php echo e($usersFollowerCount); ?> <h4 class="font-weight-normal text-muted pl-1 mr-4"> Followers </h4></h4>
                        <h4> <?php echo e($usersFollowingCount); ?> <h4 class="font-weight-normal text-muted pl-1"> Following </h4></h4>
                    </div>

                </div>

                <div class="col ">
                    <div class="text-justify"><?php echo e($users->profile->bio); ?></div>

                    <?php if(!empty ($users->profile->location)): ?>
                        <div class="pt-4"> <strong> Location </strong><br> <?php echo e($users->profile->location); ?></div>
                    <?php endif; ?>


                    <?php if(!empty ($users->profile->profession)): ?>
                        <div class="pt-4"> <strong> Profession </strong><br> <?php echo e($users->profile->profession); ?></div>
                    <?php endif; ?>

                    <?php if(!empty ($users->profile->website)): ?>
                        <div class="pt-4"> <strong> Website </strong> <br> <a href="<?php echo e($users->profile->website); ?>" ><?php echo e($users->profile->website); ?></a></div>
                    <?php endif; ?>

                </div>
                
            </div>
        </div>
    </div>
    <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Ampps\www\instagram\resources\views/profile/index.blade.php ENDPATH**/ ?>