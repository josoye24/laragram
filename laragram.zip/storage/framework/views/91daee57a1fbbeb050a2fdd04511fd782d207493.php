<div class="row align-items-center justify-content-xl-between">
    <div class="col-xl-6">
        <div class="copyright text-center text-xl-left text-muted">
            &copy; <?php echo e(now()->year); ?> <a href="https://twitter.com/josoye24" class="font-weight-bold ml-1" style="color:red" target="_blank">Joseph</a>
        </div>
    </div>
</div><?php /**PATH C:\Ampps\www\instagram\resources\views/layouts/footers/nav.blade.php ENDPATH**/ ?>